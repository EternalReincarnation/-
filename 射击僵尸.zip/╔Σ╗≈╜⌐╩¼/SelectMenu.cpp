#include "SelectMenu.h"

CSelectMenu::CSelectMenu(RECT &rectClient)
{
	this->rectClient = rectClient;
	InitMenu();
}

CSelectMenu::~CSelectMenu(void)
{

}
void CSelectMenu::InitMenu()
{
	int left = ((rectClient.right - rectClient.left))/3+150;
	int top =((rectClient.bottom - rectClient.top))/3+200;

	CResourcesPool *pResPool = CResourcesPool::GetInstance();
	pResPool->AddTexture(TEXT("up"), TEXT("Up.png"));
	pResPool->AddTexture(TEXT("down"), TEXT("Down.png"));
	pResPool->AddTexture(TEXT("menubg"), TEXT("MenuBg.png"));


	CSpritesManager *pSpritesManager = CSpritesManager::GetInstance();
	pMenuBg = pSpritesManager->CreateSprite(TEXT("menubg"), D2D1::Point2F(0, 0),480,480);
	pMenuBg->SetScaleFactor(3.2, 2.0);

	CSprite *pUp = pSpritesManager->CreateSprite(TEXT("up"), D2D1::Point2F(0, 0),260,100,0,0);
	CSprite *pDown = pSpritesManager->CreateSprite(TEXT("down"), D2D1::Point2F(0, 0),260,100,0,0);
	pButtons = new CSpriteButton(Choice, D2D1::Point2F(left, top), pUp, pDown);
	
}
bool CSelectMenu::HandleMouseUp(WPARAM wParam,LPARAM lParam)
{
	bool bRet = false;
	if (pButtons->HandleMouseUp(wParam,lParam))
		{
			bRet = true;
			if (pButtons->btnState == BtnUp)
			{
				return true;
			}
		}

	return bRet;
}
bool CSelectMenu::HandleMouseDown(WPARAM wParam,LPARAM lParam)
{
	bool bRet = false;	
	if (pButtons->HandleMouseDown(wParam,lParam))
		{
			bRet = true;
		}
	return bRet;
}
void CSelectMenu::Reset()
{
	
	pButtons->Reset();
	
}

void CSelectMenu::SetVisible(bool bVal)
{
	
	pButtons->SetVisible(bVal);
	this->bVisible = bVal;
}
bool CSelectMenu::IsVisible()
{
	return bVisible;
}
