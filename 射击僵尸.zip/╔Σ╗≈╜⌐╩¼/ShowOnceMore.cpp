#include "ShowOnceMore.h"
#include "SelectMenu.h"

CShowOnceMore::CShowOnceMore(RECT &rectClient)
{
	ShowCursor(true);
	this->rectClient = rectClient;
	Init();
}

CShowOnceMore::~CShowOnceMore(void)
{

}
void CShowOnceMore::Init()
{
	int left = ((rectClient.right - rectClient.left)) / 2.5;
	int top =((rectClient.bottom - rectClient.top)) / 3;

	CResourcesPool *pResPool = CResourcesPool::GetInstance();
	pResPool->AddTexture(TEXT("playagain"), TEXT("PlayAgain.png"));
	pResPool->AddTexture(TEXT("cancel"), TEXT("Cancel.png"));
	pResPool->AddTexture(TEXT("gameover"), TEXT("GameOver.bmp"));

	CSpritesManager *pSpritesManager = CSpritesManager::GetInstance();

	//������Ϸ��������
	pGameOver = pSpritesManager->CreateSprite(TEXT("gameover"), D2D1::Point2F(0, 0), 800, 600);
	pGameOver->SetScaleFactor(2.0, 1.4);
	
	//����������ť
	CSprite *pConfirmUp = pSpritesManager->CreateSprite(TEXT("playagain"), D2D1::Point2F(0,0),260,100, 0, 0);
	CSprite *pConfirmDown = pSpritesManager->CreateSprite(TEXT("playagain"), D2D1::Point2F(0, 0),260,100,0,0);
	pButtons[0] = new CSpriteButton(OnceMoreBtnConfirm, D2D1::Point2F(left, top+200), pConfirmUp, pConfirmDown);
	
	CSprite *pCancelUp = pSpritesManager->CreateSprite(TEXT("cancel"), D2D1::Point2F(0, 0), 260, 100, 0, 0);
	CSprite *pCancelDown = pSpritesManager->CreateSprite(TEXT("cancel"), D2D1::Point2F(0, 0), 260, 100, 0, 0);
	pButtons[1] = new CSpriteButton(OnceMoreBtnCancel, D2D1::Point2F(left, top+300), pCancelUp, pCancelDown);

	onceMoreState = OnceMoreStateNormal;

	
}
bool CShowOnceMore::HandleMouseUp(WPARAM wParam,LPARAM lParam)
{
	bool bRet = false;
	for(int i=0;i<2;i++)
	{
		if (pButtons[i]->HandleMouseUp(wParam,lParam))
		{
			bRet = true;
			if (pButtons[i]->btnState == BtnUp)
			{
				if (i == 0)
				{
					onceMoreState = OnceMoreStateConfirm;
				}
				else
				{
					onceMoreState = OnceMoreStateCancel;
				}
				break;
			}
		}
	}
	return bRet;
}
bool CShowOnceMore::HandleMouseDown(WPARAM wParam,LPARAM lParam)
{
	bool bRet = false;
	for(int i=0;i<2;i++)
	{
		if (pButtons[i]->HandleMouseDown(wParam,lParam))
		{
			bRet = true;
		}
	}
	return bRet;
}
void CShowOnceMore::Reset()
{
	onceMoreState = OnceMoreStateNormal;
	for(int i=0;i<2;i++)
	{
		pButtons[i]->Reset();
	}
}

void CShowOnceMore::SetVisible(bool bVal)
{
	for(int i=0;i<2;i++)
	{
		pButtons[i]->SetVisible(bVal);
	}
	pGameOver->SetVisible(false);
	this->bVisible = bVal;
}
bool CShowOnceMore::IsVisible()
{
	return bVisible;
}
OnceMoreState CShowOnceMore::GetState()
{
	return  onceMoreState;
}
