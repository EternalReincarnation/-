#include "Zoombie.h"

Zoombie::Zoombie()
{
	ShowCursor(false);
	playState = ZoombieAlive;
	InitZoombie();
}

Zoombie::~Zoombie(void)
{

}



void Zoombie::InitZoombie()
{
	CResourcesPool *pResPool = CResourcesPool::GetInstance();
	pResPool->AddTexture(TEXT("malezoombie"), TEXT("MaleZoombie.png"));
	pResPool->AddTexture(TEXT("femalezoombie"), TEXT("FemaleZoombie.png"));
	pResPool->AddTexture(TEXT("maledead"), TEXT("MaleDead.png"));
	pResPool->AddTexture(TEXT("femaledead"), TEXT("FemaleDead.png"));
	pResPool->AddTexture(TEXT("shoot"), TEXT("Shoot.png"));
	pResPool->AddTexture(TEXT("life"), TEXT("Life.png"));
	pResPool->AddTexture(TEXT("ammo"), TEXT("Ammo.png"));
	pResPool->AddTexture(TEXT("gun"), TEXT("Gun.png"));
	pResPool->AddTexture(TEXT("hospital"), TEXT("Hospital.jpg"));

	CSpritesManager *pSpritesManager = CSpritesManager::GetInstance();

	//��Ϸ����ͼ
	pHospital = pSpritesManager->CreateSprite(TEXT("hospital"), D2D1::Point2F(0, 0), 1024, 768, 0, 0);
	pHospital->SetScaleFactor(1.5, 1.1);

	//�����ӵ�
	for (int i = 0; i < MAX_AMMO; i++)
	{
		pAmmoSprite[i] = pSpritesManager->CreateSprite(TEXT("ammo"), D2D1::Point2F(1400, 300 + (i * 30)), 16, 92, 0, 0, D2D1::Point2F(0, 0), 1000);
		pAmmoSprite[i]->SetRotationAngle(-90.0);
	}
	//������ǹ
	pGun = pSpritesManager->CreateSprite(TEXT("gun"), D2D1::Point2F(1200, 800), 160, 200, 0, 0, D2D1::Point2F(54, 200));
	pGun->SetScaleFactor(1.5, 1.0);
	
	//�������Խ�ʬ��Ů�Խ�ʬ
	pFeamaleZoombie = pSpritesManager->CreateAnimationSprite(TEXT("femalezoombie"), 4, 10, D2D1::Point2F(778, 410), 32, 48, 0, 0, D2D1::Point2F(16, 24));
	pMaleZoombie = pSpritesManager->CreateAnimationSprite(TEXT("malezoombie"), 4, 10, D2D1::Point2F(778, 410), 32, 48, 0, 0, D2D1::Point2F(16, 24));
	//�������Խ�ʬ����ͼ��Ů�Խ�ʬ����ͼ
	pMaleDead = pSpritesManager->CreateAnimationSprite(TEXT("maledead"), 4, 10, D2D1::Point2F(100, 100), 64, 64, 0, 0, D2D1::Point2F(32, 32));
	pFeamaleDead = pSpritesManager->CreateAnimationSprite(TEXT("femaledead"), 4, 10, D2D1::Point2F(200, 200), 64, 64, 0, 0, D2D1::Point2F(32, 32));
	//��ʼ����
	pMaleDead->SetVisible(false);
	pFeamaleDead->SetVisible(false);

	//��������ֵ
	for (int i = 0; i < MAX_LIFE; i++)
	{
		pLife[i] = pSpritesManager->CreateSprite(TEXT("life"), D2D1::Point2F(1300 + (i * 40), 20), 35, 35, 0, 0);
	}

	//�������
	pFrontSight = pSpritesManager->CreateAnimationSprite(TEXT("shoot"), 4, 10, D2D1::Point2F(100, 100), 32, 32, 0, 32);

	//���Ŷ���
	pMaleZoombie->Play();
	pFeamaleZoombie->Play();
	pMaleDead->Play();
	pFeamaleDead->Play();

}

PlayState Zoombie::Update(float fDeltatime)
{
	static float t = 0;
	//����ٶ�
	/*default_random_engine e(time(0));
	uniform_real_distribution<float> speed(0.1, 0.5);*/
	
	if (playState == ZoombieAlive)
	{
		t = t + fDeltatime;
		//��������ɥʬ����Ϊ
		if (t > 0)
		{
			static float i = 0;
			i = i + 0.2;
			pMaleZoombie->SetScaleFactor(1 + (i*0.1), 1 + (i*0.1));
			pMaleZoombie->SetPos(D2D1::Point2F(778, 410 + (i * 5)));

			//��ɥʬ�ߵ�һ�����뱻ҧ
			if (i > 55.0)
			{
				pMaleZoombie->SetVisible(false);
				pMaleZoombie->SetScaleFactor(1 + (i*0.1), 1 + (i*0.1));
				pMaleZoombie->SetPos(D2D1::Point2F(778, 410 + (i * 5)));
				i = 0;
				if (pMaleZoombie->IsVisible() == false)
				{
					nPlayerHurted = nPlayerHurted + 1;
					pLife[nPlayerHurted - 1]->SetVisible(false);
					if (nPlayerHurted == 6)
					{
						playState = PlayerDead;
					}
				}
				pMaleZoombie->SetVisible(true);
			}

			//�������7ǹ��������
			if (pMaleZoombie->IsSelected(ShootvPos.x, ShootvPos.y))
			{
				if (ShootAmmo == 7)
				{
					pMaleZoombie->SetVisible(false);
					pMaleDead->SetScaleFactor(1 + (i*0.1), 1 + (i*0.1));
					pMaleDead->SetPos(D2D1::Point2F(778, 410 + (i * 5)));
					ShootAmmo = 0;
					i = 0;
					pMaleZoombie->SetVisible(true);
				}
			}
		}

		//����Ů��ɥʬ����Ϊ
		if (t > 0)
		{
			static float i = 0;
			i = i + 0.1;
			pFeamaleZoombie->SetScaleFactor(1 + (i*0.1), 1 + (i*0.1));
			pFeamaleZoombie->SetPos(D2D1::Point2F(778, 410 + (i * 5)));

			//Ůɥʬ�ߵ�һ�����뱻ҧ
			if (i > 55.0)
			{
				pFeamaleZoombie->SetVisible(false);
				pFeamaleZoombie->SetScaleFactor(1 + (i*0.1), 1 + (i*0.1));
				pFeamaleZoombie->SetPos(D2D1::Point2F(778, 410 + (i * 5)));
				i = 0;				
				if (pFeamaleZoombie->IsVisible() == false)
				{		
					nPlayerHurted = nPlayerHurted + 1;
					pLife[nPlayerHurted - 1]->SetVisible(false);	
					if (nPlayerHurted == 6)
					{
						playState = PlayerDead;
					}
				}
				pFeamaleZoombie->SetVisible(true);
			}
			//�������5ǹ��������
			if (pFeamaleZoombie->IsSelected(ShootvPos.x, ShootvPos.y))
			{
				if (ShootAmmo == 5)
				{
					pFeamaleZoombie->SetVisible(false);
					pFeamaleDead->SetScaleFactor(1 + (i*0.1), 1 + (i*0.1));
					pFeamaleDead->SetPos(D2D1::Point2F(778, 410 + (i * 5)));
					ShootAmmo = 0;
					i = 0;
					pFeamaleZoombie->SetVisible(true);
				}
			}
		}
	}

	if (playState == ZoombieDead)return playState;

	//����������
	if (playState == PlayerDead)
	{
		pMaleZoombie->SetVisible(false);
		pFeamaleZoombie->SetVisible(false);
		pFrontSight->SetVisible(false);
	}
	return playState;
}

void Zoombie::HandleMouseDown(WPARAM wParam, LPARAM lParam)
{
	ShootAmmo = ShootAmmo + 1;
	pFrontSight->SetTexPos(0, 0);
	pGun->SetRotationAngle(20.0);
	pAmmoSprite[AmmoNumber]->SetVisible(false);
	AmmoNumber++;
	if (AmmoNumber == MAX_AMMO)
	{
		for (int i = 0; i < MAX_AMMO; i++)
		{
			pAmmoSprite[i]->SetVisible(true);
			AmmoNumber = 0;
		}
	}

}

void Zoombie::HandleMouseMove(WPARAM wParam, LPARAM lParam)
{

	//��������ƶ��¼����ù�꾫��������ƶ����ƶ�
	ShootvPos.x = LOWORD(lParam);
	ShootvPos.y = HIWORD(lParam);
	pFrontSight->SetHotSpot(D2D1::Point2F(16.0f, 16.0f));
	pFrontSight->SetPos(D2D1::Point2F(ShootvPos.x, ShootvPos.y));
}

void Zoombie::HandleMouseUp(WPARAM wParam, LPARAM lParam)
{
	pFrontSight->SetTexPos(0, 32);
	pGun->SetRotationAngle(0.0);
}

void Zoombie::Clear()													//�����Ϸ����
{
	if (pAmmoSprite){ 
		for (int i = 0; i < MAX_AMMO;i++)
		pAmmoSprite[i]->SetVisible(false); 	
	}
	if (pGun){ pGun->SetVisible(false);}
	if (pHospital){ pHospital->SetVisible(false);}
	if (pFrontSight){ pFrontSight->SetVisible(false);}
	if (pMaleZoombie){ pMaleZoombie->SetVisible(false);}
	if (pFeamaleZoombie){ pFeamaleZoombie->SetVisible(false);}
	if (pLife){
		for (int i = 0; i < MAX_LIFE; i++)
			pLife[i]->SetVisible(false);
	}
}







